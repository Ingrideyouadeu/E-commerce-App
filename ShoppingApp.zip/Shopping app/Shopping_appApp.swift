//
//  Shopping_appApp.swift
//  Shopping app
//
//  Created by Ingride Youadeu on 2024-10-03.
//

import SwiftUI

@main // starting point
struct Shopping_appApp: App {
    var body:some Scene{
        WindowGroup{
            ContentView()
        }
    }
}
