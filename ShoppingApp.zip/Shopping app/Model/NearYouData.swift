//
//  NearYouData.swift
//  Shopping app
//
//  Created by Ingride Youadeu on 2024-10-03.
//

import Foundation


struct places{
    var id: Int
    var name: String
    var time: String
    var rating: String
    var image: String
}

//no need of enums
